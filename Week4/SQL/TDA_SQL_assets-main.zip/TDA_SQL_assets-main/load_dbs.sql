-- for sqlite3

.mode csv
.import people.csv people
.import combined.csv combined
.import plots.csv plots
.import species.csv species
.import surveys.csv surveys
