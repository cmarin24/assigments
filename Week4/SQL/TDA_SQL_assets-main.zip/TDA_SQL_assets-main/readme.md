TDA SQL Lesson assets

1: Clone this repository down onto your machine

2:Extract sqlite3 into root 

3: Open up a Command Prompt

4: Navigate to the sqlite root directory

5:Launch sqlite3 with the command:
'sqlite3'

6: Copy contents of load_dbs.sql into the sqlite teminal:

